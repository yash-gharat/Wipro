import zlib
class SimpleHeaderCompressor:
    def __init__(self):
        # Initialize the previous header to None
        self.previous_header = None

    def compress(self, header):
        # Simulate compression by using zlib
        # Check if the current header is the same as the previous one
        if self.previous_header == header:
            return b'\x00'  # Return a placeholder indicating no change

        # Compress the header using zlib
        compressed = zlib.compress(header.encode())
        self.previous_header = header  # Update the previous header
        return compressed  # Return the compressed header

    def decompress(self, compressed_header):
        # Check if the compressed header is the placeholder
        if compressed_header == b'\x00':
            return self.previous_header  # Return the previous header

        # Decompress the header using zlib
        return zlib.decompress(compressed_header).decode()


# Example usage
compressor = SimpleHeaderCompressor()

header1 = "GET /index.html HTTP/1.1"  # First HTTP header
header2 = "GET /index.html HTTP/1.1"  # Same header for testing

# Compress the first header
compressed_header1 = compressor.compress(header1)
print("Compressed Header 1:", compressed_header1)

# Compress the second header (should detect it's the same)
compressed_header2 = compressor.compress(header2)
print("Compressed Header 2:", compressed_header2)

# Decompress the compressed header
decompressed_header = compressor.decompress(compressed_header1)
print("Decompressed Header:", decompressed_header)
