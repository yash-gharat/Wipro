import zlib
import json

class HeaderCompressor:
    def __init__(self):
        self.sequence_number = 0
        self.headers = {}

    def add_header(self, key, value):
        self.sequence_number += 1
        self.headers[self.sequence_number] = (key, value)

    def compress_headers(self):
        # Convert headers to JSON and compress using zlib
        headers_json = json.dumps(self.headers)
        compressed = zlib.compress(headers_json.encode())
        return compressed

# Example usage
compressor = HeaderCompressor()
compressor.add_header("Content-Type", "application/json")
compressor.add_header("Authorization", "Bearer token")

compressed_headers = compressor.compress_headers()
print(f"Compressed Headers: {compressed_headers}")
