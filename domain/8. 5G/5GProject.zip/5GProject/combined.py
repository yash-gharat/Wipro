import zlib
import json
import hmac
import hashlib

class HeaderCompressor:
    def __init__(self):
        self.sequence_number = 0
        self.headers = {}

    def add_header(self, key, value):
        self.sequence_number += 1
        self.headers[self.sequence_number] = (key, value)

    def compress_headers(self):
        headers_json = json.dumps(self.headers)
        compressed = zlib.compress(headers_json.encode())
        return compressed

class IntegrityProtector:
    def __init__(self, secret_key):
        self.secret_key = secret_key.encode()

    def generate_signature(self, data):
        return hmac.new(self.secret_key, data, hashlib.sha256).hexdigest()

# Example usage
compressor = HeaderCompressor()
compressor.add_header("Content-Type", "application/json")
compressor.add_header("Authorization", "Bearer token")

compressed_headers = compressor.compress_headers()

protector = IntegrityProtector("my_secret_key")
signature = protector.generate_signature(compressed_headers)

print(f"Compressed Headers: {compressed_headers}")
print(f"Signature: {signature}")
