from cryptography.hazmat.primitives import cmac
from cryptography.hazmat.primitives.ciphers import algorithms
import os


def generate_key():
    # Generates a random 16-byte key for AES-128
    return os.urandom(16)


def create_mac(key, data):
    # Create a CMAC object using the AES algorithm
    c = cmac.CMAC(algorithms.AES(key))
    c.update(data)
    return c.finalize()


def verify_mac(key, data, mac):
    # Create a CMAC object and verify the MAC
    c = cmac.CMAC(algorithms.AES(key))
    c.update(data)
    try:
        c.verify(mac)
        return True
    except ValueError:
        return False


def test_integrity_protection():
    key = generate_key()
    data = b"Data to protect"
    modified_data = b"Modified data"
    print("Original data:", data)
    mac = create_mac(key, data)
    # Introduce errors in the first few checks
    # print("Attempt 1: Verifying with modified data")
    # print("MAC verification attempt 1:", "passed" if verify_mac(key, modified_data, mac) else "failed")

    # print("Attempt 2: Verifying with wrong MAC")
    # wrong_mac = b'\x00' * 16  # Deliberately incorrect MAC
    # print("MAC verification attempt 2:", "passed" if verify_mac(key, data, wrong_mac) else "failed")

    print("Attempt 3: Correct verification")
    print("Generated MAC:", mac)
    print("MAC verification attempt 3:", "passed" if verify_mac(key, data, mac) else "failed")

    return "Integrity test completed!"


# Run the integrity protection test
print(test_integrity_protection())