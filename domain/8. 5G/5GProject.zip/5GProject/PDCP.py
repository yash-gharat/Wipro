import threading
import hmac
import hashlib
from Crypto.Cipher import AES
import os


class PDCPSequenceNumberHandler:
    def __init__(self, start=0, max_value=2 ** 16 - 1, key=None):
        self.current_sn = start
        self.max_value = max_value
        self.packet_buffer = {}
        self.lock = threading.Lock()
        self.key = key or os.urandom(16)  # Generate a random key if none provided

    def get_next_sequence_number(self):
        with self.lock:
            next_sn = (self.current_sn + 1) % (self.max_value + 1)
            return next_sn

    def receive_packet(self, sequence_number, packet_data, integrity_hash):
        with self.lock:
            # Check the integrity of the packet
            if not self.verify_integrity(packet_data, integrity_hash):
                print(f"Integrity check failed for packet {sequence_number}")
                return

            # Check if the packet's sequence number is the expected one
            if sequence_number == self.current_sn:
                self.process_packet(packet_data)
                self.current_sn = (self.current_sn + 1) % (self.max_value + 1)
                self.handle_retransmissions()
            elif sequence_number > self.current_sn:
                self.packet_buffer[sequence_number] = packet_data

    def process_packet(self, packet_data):
        print(f"Processing packet with data: {packet_data}")

    def handle_retransmissions(self):
        while self.current_sn in self.packet_buffer:
            packet_data = self.packet_buffer.pop(self.current_sn)
            self.process_packet(packet_data)
            self.current_sn = (self.current_sn + 1) % (self.max_value + 1)

    def reset_sequence_number(self, start=0):
        with self.lock:
            self.current_sn = start
            self.packet_buffer.clear()

    def verify_integrity(self, packet_data, integrity_hash):
        expected_hash = hmac.new(self.key, packet_data.encode(), hashlib.sha256).hexdigest()
        return expected_hash == integrity_hash

    def encrypt_packet(self, packet_data):
        cipher = AES.new(self.key, AES.MODE_EAX)
        ciphertext, tag = cipher.encrypt_and_digest(packet_data.encode())
        return cipher.nonce, ciphertext, tag

    def decrypt_packet(self, nonce, ciphertext, tag):
        cipher = AES.new(self.key, AES.MODE_EAX, nonce=nonce)
        decrypted_data = cipher.decrypt_and_verify(ciphertext, tag)
        return decrypted_data.decode()


# Example usage
if __name__ == "__main__":
    pdcp_handler = PDCPSequenceNumberHandler(start=0)

    # Simulate packet encryption and integrity check
    packet_data = "Data for packet 0"
    nonce, ciphertext, tag = pdcp_handler.encrypt_packet(packet_data)
    integrity_hash = hmac.new(pdcp_handler.key, packet_data.encode(), hashlib.sha256).hexdigest()

    # Send the packet
    pdcp_handler.receive_packet(0, packet_data, integrity_hash)

    # Simulating receiving the encrypted packet
    decrypted_data = pdcp_handler.decrypt_packet(nonce, ciphertext, tag)
    print(f"Decrypted data: {decrypted_data}")

    # Receiving the next packet
    packet_data = "Data for packet 1"
    integrity_hash = hmac.new(pdcp_handler.key, packet_data.encode(), hashlib.sha256).hexdigest()
    pdcp_handler.receive_packet(1, packet_data, integrity_hash)

    # Simulating a packet out of order
    packet_data = "Data for packet 2"
    integrity_hash = hmac.new(pdcp_handler.key, packet_data.encode(), hashlib.sha256).hexdigest()
    pdcp_handler.receive_packet(2, packet_data, integrity_hash)  # Should be buffered

    # The next packet is expected to be 2, so this will process the buffered packet
    pdcp_handler.receive_packet(2, packet_data, integrity_hash)
