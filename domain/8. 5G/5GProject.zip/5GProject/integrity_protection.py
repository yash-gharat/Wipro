import hmac
import hashlib

class IntegrityProtector:
    def __init__(self, secret_key):
        self.secret_key = secret_key.encode()

    def generate_signature(self, data):
        return hmac.new(self.secret_key, data, hashlib.sha256).hexdigest()

# Example usage
protector = IntegrityProtector("my_secret_key")
data_to_protect = b"Learning 5G"
signature = protector.generate_signature(data_to_protect)

print(f"Data: {data_to_protect}")
print(f"Signature: {signature}")
